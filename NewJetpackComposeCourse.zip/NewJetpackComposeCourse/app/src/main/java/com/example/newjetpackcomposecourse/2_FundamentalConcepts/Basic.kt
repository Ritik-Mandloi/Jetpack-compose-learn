package com.example.newjetpackcomposecourse.`2_FundamentalConcepts`

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview

// what is the Composable Function

@Composable
fun Greeting(){
    Text(text = "Hello Jetpack Compose")
}


